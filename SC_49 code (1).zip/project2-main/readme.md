                         **\**********DISASTER TWEETS CLASSIFICATION********\*\**

This project helps to classify tweets,it will help various organizations like NGO and etc.

we built a model using twitter data
we are taken a data by specifying keywords like 'Earthquake','floods','tsunami' and etc directly from the twitter application

scrapped the data using snscrape module and built a model in colab.

IDE Used:

VS CODE

PYCHARM : Anaconda Navigator v23. 3.1. Version

architec (1).drawio.png
Architecture diagram of our model was drawn through draw.io.

Front end part was developed through streamlite.
